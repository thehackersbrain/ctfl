# CTFL
> CTFTime Upcoming CTF events lists

## Installation

```bash
pip3 install ctfl
```
